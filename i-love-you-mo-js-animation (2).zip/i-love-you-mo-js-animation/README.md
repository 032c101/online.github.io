# I Love You (mo.js animation)

A Pen created on CodePen.io. Original URL: [https://codepen.io/mudrenok/pen/XMobMa](https://codepen.io/mudrenok/pen/XMobMa).

<img src="https://media.giphy.com/media/3oKIPjBudwsQAuuu8E/giphy.gif" height="180" width="180"/>

<a href="https://dribbble.com/shots/3278810-I-Love-You-Responsive">Dribbble Shot</a> by <a href="https://twitter.com/galgalshir">Gal Shir</a> 